# Entry point for Q-IDS
from data_loader import load_data
from preprocessing import preprocess
from quantum_model import QuantumIDS
from evaluation import evaluate

X, y = load_data('dataset.csv')
X_train, X_test, y_train, y_test = preprocess(X, y)
model = QuantumIDS()
model.train(X_train, y_train)
preds = model.predict(X_test)
evaluate(y_test, preds)
