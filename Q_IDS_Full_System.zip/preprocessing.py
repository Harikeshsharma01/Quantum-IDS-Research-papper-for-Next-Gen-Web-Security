from sklearn.preprocessing import MinMaxScaler
from sklearn.decomposition import PCA
from sklearn.model_selection import train_test_split

def preprocess(X, y):
    scaler = MinMaxScaler()
    X_scaled = scaler.fit_transform(X)
    pca = PCA(n_components=4)
    X_red = pca.fit_transform(X_scaled)
    return train_test_split(X_red, y, test_size=0.2, random_state=42)
