import pandas as pd

def load_data(path):
    df = pd.read_csv(path)
    df = df.dropna()
    X = df.drop('Label', axis=1).values
    y = df['Label'].values
    return X, y
