
# Quantum-Based Intrusion Detection System (Q-IDS)

Author: Harikesh Mahendra Sharma

This project implements a hybrid quantum-classical intrusion detection system.

## How to Run
1. Install dependencies: pip install pennylane pandas scikit-learn numpy
2. Add your dataset as dataset.csv
3. Run: python main.py
